var app = app || {};

app.Note = Backbone.Model.extend({
});
